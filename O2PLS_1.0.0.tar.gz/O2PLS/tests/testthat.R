library(testthat)
library(O2PLS)

test_check("O2PLS")
